"""Database configuration and initialization of 557 seats with reserved first rows."""

from sqlalchemy import create_engine, inspect
from sqlalchemy.orm import sessionmaker
from models import Base, Seat

DATABASE_URL = "sqlite:///./hall.db"

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


# =========================================================================
# Hall layout configuration (single source of truth)
# =========================================================================
#
# Left sector:   10 seats x 19 rows           = 190 seats
# Center sector: Row 1 = 7 seats, Rows 2-18 = 10 seats each = 7 + 170 = 177 seats
# Right sector:  10 seats x 19 rows           = 190 seats
# Total: 190 + 177 + 190 = 557 seats
#
# Row 1 of each sector is RESERVED (permanently occupied, no guest).

HALL_CONFIG = {
    "left": {
        "label": "Левый",
        "seats_per_row": 10,
        "rows": 19,
        "first_row_seats": 10,  # row 1 seat count (same as seats_per_row)
    },
    "center": {
        "label": "Центральный",
        "seats_per_row": 10,
        "rows": 18,
        "first_row_seats": 7,   # row 1 has only 7 seats, centered
    },
    "right": {
        "label": "Правый",
        "seats_per_row": 10,
        "rows": 19,
        "first_row_seats": 10,  # row 1 seat count (same as seats_per_row)
    },
}

TOTAL_SEATS = 557  # precomputed for quick checks


def get_seats_in_row(sector_key: str, row: int) -> int:
    """Return the number of seats in a given row of a sector."""
    conf = HALL_CONFIG[sector_key]
    if row == 1:
        return conf.get("first_row_seats", conf["seats_per_row"])
    return conf["seats_per_row"]


def get_db():
    """Dependency for FastAPI -- yields a DB session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def _needs_migration(db) -> bool:
    """Check if the seats table needs recreation."""
    inspector = inspect(engine)

    # Table doesn't exist yet
    if "seats" not in inspector.get_table_names():
        return True

    # Check if is_reserved column exists
    columns = {col["name"] for col in inspector.get_columns("seats")}
    if "is_reserved" not in columns:
        return True

    # Check seat count
    existing = db.query(Seat).count()
    if existing != TOTAL_SEATS:
        return True

    return False


def init_db():
    """Create tables and populate 557 seats if not already present.

    Safe migration: if the old 500-seat layout or missing is_reserved
    column is detected, the seats table is dropped and recreated.
    Guest records are preserved; their seat assignments are reset.
    """
    # Ensure all tables exist (creates guests table if missing)
    Base.metadata.create_all(bind=engine)

    db = SessionLocal()
    try:
        # Add category column to guests if missing
        try:
            inspector = inspect(engine)
            if "guests" in inspector.get_table_names():
                guest_cols = {col["name"] for col in inspector.get_columns("guests")}
                if "category" not in guest_cols:
                    print("[MIGRATION] Adding category column to guests table...")
                    with engine.begin() as conn:
                        from sqlalchemy import text
                        conn.execute(text("ALTER TABLE guests ADD COLUMN category VARCHAR(200)"))
        except Exception as e:
            print(f"[ERROR] Migration failed: {e}")
        
        if not _needs_migration(db):
            return  # already up to date

        print("[MIGRATION] Seat structure mismatch detected — recreating seats table...")

        # Reset guest assignments before dropping seats
        from models import Guest
        try:
            # Clear FK references so guests survive
            db.query(Seat).update({Seat.guest_id: None})
            db.commit()
        except Exception:
            db.rollback()

        # Drop and recreate the seats table only
        Seat.__table__.drop(engine, checkfirst=True)
        Seat.__table__.create(engine, checkfirst=True)

        # Populate seats
        seats = []
        for sector_key, config in HALL_CONFIG.items():
            for row in range(1, config["rows"] + 1):
                num_seats = get_seats_in_row(sector_key, row)
                is_reserved = (row == 1)
                for num in range(1, num_seats + 1):
                    seat = Seat(
                        sector=sector_key,
                        sector_label=config["label"],
                        row=row,
                        number=num,
                        is_reserved=is_reserved,
                        guest_id=None,
                    )
                    seats.append(seat)

        db.add_all(seats)
        db.commit()

        reserved_count = sum(1 for s in seats if s.is_reserved)
        print(f"[OK] Initialized {len(seats)} seats ({reserved_count} reserved in first rows).")
    finally:
        db.close()
