import csv
import re
import uuid
from sqlalchemy.orm import Session
from database import SessionLocal, init_db
from models import Seat, Guest

def clean_name(name):
    if not name:
        return ""
    # Remove leading/trailing spaces and collapse multiple spaces
    return re.sub(r'\s+', ' ', name.strip())

def main():
    print("Инициализация и проверка базы данных...")
    init_db()

    db = SessionLocal()
    try:
        with open("seating_rows2-19.csv", "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            csv_rows = list(reader)

        sector_map = {"A": "left", "B": "center", "C": "right"}
        reverse_sector_map = {"left": "A", "center": "B", "right": "C"}
        
        # Загружаем все места для быстрого сопоставления
        all_seats = db.query(Seat).all()
        seat_dict = {(s.sector, s.row, s.number): s for s in all_seats}

        mismatches = []
        for r in csv_rows:
            sec = sector_map.get(r['sector'])
            row = int(r['row'])
            num = int(r['seat_position'])
            if (sec, row, num) not in seat_dict:
                mismatches.append(f"Сектор {r['sector']}, Ряд {r['row']}, Место {r['seat_position']}")

        if mismatches:
            print("ОШИБКА: Следующие строки из CSV не найдены в базе данных (несоответствие конфигурации зала):")
            for m in mismatches:
                print(f" - {m}")
            return

        # Идемпотентность: очищаем назначения и удаляем гостей только для рядов >= 2
        seats_2_19 = [s for s in all_seats if s.row >= 2]
        old_guest_ids = [s.guest_id for s in seats_2_19 if s.guest_id]

        for s in seats_2_19:
            s.guest_id = None
        db.flush()

        if old_guest_ids:
            db.query(Guest).filter(Guest.id.in_(old_guest_ids)).delete(synchronize_session=False)
            db.flush()

        stats = {
            "assigned": {"A": 0, "B": 0, "C": 0},
            "free": {"A": 0, "B": 0, "C": 0},
            "named": 0,
            "label": 0
        }

        # Загрузка и распределение
        samples = []
        for r in csv_rows:
            sec_key = sector_map[r['sector']]
            row_idx = int(r['row'])
            seat_num = int(r['seat_position'])
            kind = r['kind']
            cat = r['category'].strip() if r['category'] else None
            val = clean_name(r['value'])

            seat = seat_dict[(sec_key, row_idx, seat_num)]

            if kind in ['named', 'label']:
                guest = Guest(
                    name=val,
                    category=cat,
                    token=str(uuid.uuid4())
                )
                db.add(guest)
                db.flush()  # получаем ID гостя
                seat.guest_id = guest.id
                
                stats["assigned"][r['sector']] += 1
                stats[kind] += 1
                
                # Собираем пару примеров для отчета
                if len(samples) < 3 and guest.id % 7 == 0:
                    samples.append(f"Сектор {r['sector']} / Ряд {row_idx} / Место {seat_num} -> {val} ({cat or 'без категории'})")

            elif kind == 'empty':
                stats["free"][r['sector']] += 1

        db.commit()

        # Формируем отчет
        print("\n--- ОТЧЁТ ПОСЛЕ ЗАГРУЗКИ ---")
        print(f"1. Строк в CSV: {len(csv_rows)}. Сопоставлено с местами: {len(csv_rows)}.")
        
        a_as = stats["assigned"]["A"]
        b_as = stats["assigned"]["B"]
        c_as = stats["assigned"]["C"]
        
        a_fr = stats["free"]["A"]
        b_fr = stats["free"]["B"]
        c_fr = stats["free"]["C"]
        
        print(f"2. Назначено гостей по секторам: A = {a_as}, B = {b_as}, C = {c_as}")
        print(f"   Свободно мест (по CSV): A = {a_fr}, B = {b_fr}, C = {c_fr}")
        print(f"3. Гостей (named): {stats['named']}, Меток (label): {stats['label']}")
        
        total_seats = len(all_seats)
        reserved_seats = sum(1 for s in all_seats if s.is_reserved)
        print(f"4. Всего мест в базе: {total_seats}. Зарезервировано (1-й ряд): {reserved_seats}.")
        
        print("5. Случайные примеры загруженных мест:")
        if not samples:
             assigned_seats = [s for s in seats_2_19 if s.guest_id]
             for i in range(min(3, len(assigned_seats))):
                 s = assigned_seats[i]
                 sec_rev = reverse_sector_map[s.sector]
                 samples.append(f"Сектор {sec_rev} / Ряд {s.row} / Место {s.number} -> {s.guest.name} ({s.guest.category or 'без категории'})")
                 
        for samp in samples[:3]:
            print(f"   - {samp}")

    except Exception as e:
        db.rollback()
        print(f"ОШИБКА во время загрузки: {e}")
    finally:
        db.close()

if __name__ == "__main__":
    main()
