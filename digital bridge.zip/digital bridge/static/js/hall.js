/**
 * Digital Bridge — Interactive Hall SVG Renderer
 * Generates an SVG seating chart for the main hall page.
 * Config is fetched from /api/hall-config (single source of truth).
 */

// Hall visual constants (layout params come from API)
const HALL = {
    width: 900,
    height: 480,
    padding: 30,
    screenY: 25,
    screenHeight: 30,
    screenWidth: 550,
    seatSize: 12,
    seatGap: 3,
    rowGap: 4,
    sectorGap: 40,
    entranceY: 430,
    sectors: null,  // populated from /api/hall-config
    entrances: [
        { id: 'A', label: 'Вход A' },
        { id: 'Б', label: 'Вход Б' },
    ],
};

let allSeats = [];
let selectedSeatId = null;
let dashboardQR = null; // cached universal QR image (base64)

/**
 * Get number of seats in a given row for a sector.
 */
function getSeatsInRow(sectorKey, row) {
    const conf = HALL.sectors[sectorKey];
    if (row === 1 && conf.first_row_seats !== undefined) {
        return conf.first_row_seats;
    }
    return conf.seats_per_row;
}

/**
 * Calculate X positions for each sector.
 * Width is based on max seats_per_row (applies to rows 2+).
 */
function calculateSectorPositions() {
    const seatUnit = HALL.seatSize + HALL.seatGap;
    const leftWidth = HALL.sectors.left.seats_per_row * seatUnit;
    const centerWidth = HALL.sectors.center.seats_per_row * seatUnit;
    const rightWidth = HALL.sectors.right.seats_per_row * seatUnit;
    const totalWidth = leftWidth + centerWidth + rightWidth + 2 * HALL.sectorGap;
    const startX = (HALL.width - totalWidth) / 2;

    return {
        left:   { x: startX, width: leftWidth },
        center: { x: startX + leftWidth + HALL.sectorGap, width: centerWidth },
        right:  { x: startX + leftWidth + centerWidth + 2 * HALL.sectorGap, width: rightWidth },
    };
}

/**
 * Create an SVG element with attributes.
 */
function svgEl(tag, attrs) {
    const el = document.createElementNS('http://www.w3.org/2000/svg', tag);
    for (const [key, val] of Object.entries(attrs)) {
        el.setAttribute(key, val);
    }
    return el;
}

/**
 * Render the hall SVG with all seats.
 */
function renderHall(svgId, seats) {
    const svg = document.getElementById(svgId);
    if (!svg) return;
    if (!HALL.sectors) return; // config not loaded yet
    svg.innerHTML = '';

    // Update viewBox to match HALL dimensions
    svg.setAttribute('viewBox', `0 0 ${HALL.width} ${HALL.height}`);

    const positions = calculateSectorPositions();
    const seatUnit = HALL.seatSize + HALL.seatGap;

    // Background
    svg.appendChild(svgEl('rect', {
        x: 0, y: 0, width: HALL.width, height: HALL.height,
        fill: '#0f172a', rx: 12,
    }));

    // Screen
    const screenX = (HALL.width - HALL.screenWidth) / 2;
    svg.appendChild(svgEl('rect', {
        x: screenX, y: HALL.screenY, width: HALL.screenWidth, height: HALL.screenHeight,
        class: 'hall-screen', fill: '#475569', rx: 6,
    }));
    const screenLabel = svgEl('text', {
        x: HALL.width / 2, y: HALL.screenY + HALL.screenHeight / 2 + 4,
        'text-anchor': 'middle', fill: '#94a3b8', 'font-size': '12', 'font-weight': '600',
    });
    screenLabel.textContent = 'ЭКРАН';
    svg.appendChild(screenLabel);

    // Starting Y for seats (below screen)
    const seatsStartY = HALL.screenY + HALL.screenHeight + 35;

    // Draw sectors
    const sectorOrder = ['left', 'center', 'right'];
    const seatElements = {};

    for (const sectorKey of sectorOrder) {
        const sectorConf = HALL.sectors[sectorKey];
        const pos = positions[sectorKey];

        // Sector label
        const label = svgEl('text', {
            x: pos.x + pos.width / 2,
            y: seatsStartY - 12,
            class: 'sector-label',
        });
        label.textContent = sectorConf.label;
        svg.appendChild(label);

        // Sector background
        const totalRowHeight = sectorConf.rows * (HALL.seatSize + HALL.rowGap);
        svg.appendChild(svgEl('rect', {
            x: pos.x - 6, y: seatsStartY - 4,
            width: pos.width + 12, height: totalRowHeight + 8,
            fill: '#1e293b', rx: 8, opacity: 0.5,
        }));

        // Seats
        for (let row = 0; row < sectorConf.rows; row++) {
            const y = seatsStartY + row * (HALL.seatSize + HALL.rowGap);
            const rowNum = row + 1;
            const seatsInThisRow = getSeatsInRow(sectorKey, rowNum);

            // Row label
            if (sectorKey === 'left') {
                const rl = svgEl('text', {
                    x: pos.x - 14, y: y + HALL.seatSize / 2,
                    class: 'row-label',
                });
                rl.textContent = rowNum;
                svg.appendChild(rl);
            }

            // Calculate X offset to center rows with fewer seats
            const rowWidth = seatsInThisRow * seatUnit;
            const xOffset = (pos.width - rowWidth) / 2;

            for (let num = 0; num < seatsInThisRow; num++) {
                const x = pos.x + xOffset + num * seatUnit;

                // Find matching seat data
                const seatData = seats.find(s =>
                    s.sector === sectorKey &&
                    s.row === rowNum &&
                    s.number === num + 1
                );

                if (!seatData) continue;

                // Determine CSS class based on state
                let seatClass;
                if (seatData.is_reserved) {
                    seatClass = 'seat seat-reserved';
                } else if (seatData.is_occupied) {
                    seatClass = 'seat seat-occupied';
                } else {
                    seatClass = 'seat seat-free';
                }

                const rect = svgEl('rect', {
                    x: x, y: y,
                    width: HALL.seatSize, height: HALL.seatSize,
                    class: seatClass,
                    rx: 3,
                    'data-seat-id': seatData.id,
                });

                // Tooltip
                const title = svgEl('title', {});
                if (seatData.is_reserved) {
                    title.textContent = `Занято — ${seatData.sector_label}, Ряд ${seatData.row}, Место ${seatData.number}`;
                } else if (seatData.is_occupied) {
                    title.textContent = `${seatData.guest_name} — ${seatData.sector_label}, Ряд ${seatData.row}, Место ${seatData.number}`;
                } else {
                    title.textContent = `Свободно — ${seatData.sector_label}, Ряд ${seatData.row}, Место ${seatData.number}`;
                }
                rect.appendChild(title);

                rect.addEventListener('click', () => selectSeat(seatData.id));
                svg.appendChild(rect);
                seatElements[seatData.id] = rect;
            }
        }

        // Aisle between rows 10 and 11
        const aisleRow = Math.min(10, sectorConf.rows);
        const aisleY = seatsStartY + aisleRow * (HALL.seatSize + HALL.rowGap) - HALL.rowGap / 2;
        svg.appendChild(svgEl('line', {
            x1: pos.x - 6, y1: aisleY,
            x2: pos.x + pos.width + 6, y2: aisleY,
            stroke: '#334155', 'stroke-width': 1, 'stroke-dasharray': '4 3',
        }));
    }

    // Entrances
    const entrancePositions = {
        A: positions.left.x + positions.left.width + HALL.sectorGap / 2,
        'Б': positions.center.x + positions.center.width + HALL.sectorGap / 2,
    };

    for (const ent of HALL.entrances) {
        const ex = entrancePositions[ent.id];

        // Entrance arrow
        svg.appendChild(svgEl('rect', {
            x: ex - 25, y: HALL.entranceY - 10,
            width: 50, height: 22,
            class: 'entrance-marker', rx: 6,
        }));

        const entLabel = svgEl('text', {
            x: ex, y: HALL.entranceY + 5,
            'text-anchor': 'middle', fill: 'white', 'font-size': '10', 'font-weight': '700',
        });
        entLabel.textContent = ent.label;
        svg.appendChild(entLabel);
    }

    return seatElements;
}

/**
 * Get CSS class for a seat based on its data.
 */
function getSeatClass(seatData) {
    if (seatData.is_reserved) return 'seat seat-reserved';
    if (seatData.is_occupied) return 'seat seat-occupied';
    return 'seat seat-free';
}

/**
 * Select a seat and show its details in the side panel.
 */
async function selectSeat(seatId) {
    // Remove previous selection
    const prevSelected = document.querySelector('.seat-selected');
    if (prevSelected) {
        prevSelected.classList.remove('seat-selected');
        const prevData = allSeats.find(s => s.id === parseInt(prevSelected.getAttribute('data-seat-id')));
        if (prevData) {
            prevSelected.setAttribute('class', getSeatClass(prevData));
        }
    }

    // Highlight new selection (only if not already highlighted by search)
    const seatEl = document.querySelector(`[data-seat-id="${seatId}"]`);
    if (seatEl && !seatEl.classList.contains('seat-highlight')) {
        seatEl.setAttribute('class', 'seat seat-selected');
    }

    selectedSeatId = seatId;

    // Fetch seat details
    try {
        const response = await fetch(`/api/seat/${seatId}`);
        const data = await response.json();
        showSeatPanel(data);
    } catch (err) {
        console.error('Failed to fetch seat info:', err);
    }
}

/**
 * Show seat details in the right panel.
 * Reserved seats: only location + "Занято", no guest info, QR, or buttons.
 */
function showSeatPanel(data) {
    const panel = document.getElementById('side-panel');
    const content = document.getElementById('panel-content');

    panel.classList.remove('hidden-panel');
    panel.classList.add('visible-panel');

    // --- Reserved seat: minimal panel ---
    if (data.is_reserved) {
        content.innerHTML = `
            <div class="space-y-5">
                <!-- Seat location -->
                <div class="bg-gray-800 rounded-xl p-4">
                    <p class="text-xs text-gray-400 mb-3">Расположение</p>
                    <div class="grid grid-cols-3 gap-2 text-center">
                        <div class="bg-gray-700/50 rounded-lg p-2">
                            <p class="text-gray-400 text-xs">Сектор</p>
                            <p class="text-white font-semibold text-sm">${data.sector_label}</p>
                        </div>
                        <div class="bg-gray-700/50 rounded-lg p-2">
                            <p class="text-gray-400 text-xs">Ряд</p>
                            <p class="text-white font-semibold text-lg">${data.row}</p>
                        </div>
                        <div class="bg-gray-700/50 rounded-lg p-2">
                            <p class="text-gray-400 text-xs">Место</p>
                            <p class="text-white font-semibold text-lg">${data.number}</p>
                        </div>
                    </div>
                </div>

                <!-- Status badge -->
                <div class="text-center">
                    <span class="inline-block px-4 py-1.5 rounded-full text-sm font-medium
                        bg-blue-600/20 text-blue-300 border border-blue-600/30">
                        ● Занято
                    </span>
                </div>
            </div>
        `;
        return;
    }

    // --- Normal seat panel ---
    content.innerHTML = `
        <div class="space-y-5">
            <!-- Guest info -->
            <div class="bg-gray-800 rounded-xl p-4">
                <div class="flex items-center gap-3 mb-3">
                    <div class="w-10 h-10 rounded-full flex items-center justify-center ${data.is_occupied ? 'bg-blue-600/30' : 'bg-gray-700'}">
                        <svg class="w-5 h-5 ${data.is_occupied ? 'text-blue-400' : 'text-gray-500'}" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                        </svg>
                    </div>
                    <div>
                        <p class="text-xs text-gray-400">Гость</p>
                        <p class="text-white font-semibold">${data.guest_name || 'Не назначен'}</p>
                    </div>
                </div>
            </div>

            <!-- Seat location -->
            <div class="bg-gray-800 rounded-xl p-4">
                <p class="text-xs text-gray-400 mb-3">Расположение</p>
                <div class="grid grid-cols-3 gap-2 text-center">
                    <div class="bg-gray-700/50 rounded-lg p-2">
                        <p class="text-gray-400 text-xs">Сектор</p>
                        <p class="text-white font-semibold text-sm">${data.sector_label}</p>
                    </div>
                    <div class="bg-gray-700/50 rounded-lg p-2">
                        <p class="text-gray-400 text-xs">Ряд</p>
                        <p class="text-white font-semibold text-lg">${data.row}</p>
                    </div>
                    <div class="bg-gray-700/50 rounded-lg p-2">
                        <p class="text-gray-400 text-xs">Место</p>
                        <p class="text-white font-semibold text-lg">${data.number}</p>
                    </div>
                </div>
            </div>

            <!-- QR Code — universal, leads to dashboard -->
            <div class="bg-gray-800/60 rounded-xl p-4 text-center">
                <p class="text-xs text-gray-400 mb-3">QR-код — вход на сайт</p>
                <div class="qr-container mx-auto mb-3">
                    <img id="universal-qr" src="" alt="QR" class="w-36 h-36">
                </div>
                <p class="text-gray-500 text-xs">Сканируйте для перехода на дашборд</p>
            </div>

            <!-- Status badge -->
            <div class="text-center">
                <span class="inline-block px-4 py-1.5 rounded-full text-sm font-medium ${
                    data.is_occupied
                        ? 'bg-blue-600/20 text-blue-300 border border-blue-600/30'
                        : 'bg-green-600/20 text-green-300 border border-green-600/30'
                }">
                    ${data.is_occupied ? '● Занято' : '○ Свободно'}
                </span>
            </div>
        </div>
    `;

    // Set the universal QR image
    const qrEl = document.getElementById('universal-qr');
    if (qrEl && dashboardQR) {
        qrEl.src = dashboardQR;
    }
}

/**
 * Close the side panel.
 */
function closePanel() {
    const panel = document.getElementById('side-panel');
    panel.classList.add('hidden-panel');
    panel.classList.remove('visible-panel');

    // Deselect seat
    const selected = document.querySelector('.seat-selected');
    if (selected && selectedSeatId) {
        const data = allSeats.find(s => s.id === selectedSeatId);
        if (data) {
            selected.setAttribute('class', getSeatClass(data));
        }
    }
    selectedSeatId = null;
}

/**
 * Update statistics display.
 */
function updateStats(seats) {
    const reserved = seats.filter(s => s.is_reserved).length;
    const occupiedByGuest = seats.filter(s => s.is_occupied && !s.is_reserved).length;
    const free = seats.length - reserved - occupiedByGuest;
    const freeEl = document.getElementById('stats-free');
    const occEl = document.getElementById('stats-occupied');
    if (freeEl) freeEl.textContent = free;
    if (occEl) occEl.textContent = occupiedByGuest + reserved;
}

/**
 * Load hall config from API, then load seats and render.
 */
async function loadHall() {
    try {
        // Fetch config first (single source of truth)
        const configResp = await fetch('/api/hall-config');
        const config = await configResp.json();
        HALL.sectors = config;

        const [seatsResp, qrResp] = await Promise.all([
            fetch('/api/seats'),
            fetch('/api/dashboard-qr'),
        ]);
        allSeats = await seatsResp.json();
        const qrData = await qrResp.json();
        dashboardQR = qrData.qr_image;
        renderHall('hall-svg', allSeats);
        updateStats(allSeats);
    } catch (err) {
        console.error('Failed to load hall data:', err);
    }
}

// ================================================================
// Guest Search + Navigation Path on Main Hall
// ================================================================

let highlightedSeatId = null;

/**
 * Search guests by name query (client-side, from allSeats).
 * EXCLUDES reserved seats — they have no guest.
 */
function searchGuests(query) {
    if (!query || query.length < 2) return [];
    const q = query.toLowerCase();
    return allSeats.filter(s =>
        !s.is_reserved && s.is_occupied && s.guest_name && s.guest_name.toLowerCase().includes(q)
    );
}

/**
 * Highlight a guest's seat on the main hall SVG with navigation path.
 */
function highlightGuestSeat(seat) {
    // Clear previous highlight
    clearHighlight();

    highlightedSeatId = seat.id;

    // Mark the seat element
    const seatEl = document.querySelector(`[data-seat-id="${seat.id}"]`);
    if (seatEl) {
        seatEl.setAttribute('class', 'seat seat-highlight');
        seatEl.style.fill = '#ef4444';
        seatEl.style.opacity = '1';
    }

    // Draw navigation path on the main SVG
    const svg = document.getElementById('hall-svg');
    if (svg && HALL.sectors) {
        const positions = calculateSectorPositions();
        const seatUnit = HALL.seatSize + HALL.seatGap;
        const seatsStartY = HALL.screenY + HALL.screenHeight + 35;

        // Calculate seat position (account for centered first row)
        const sectorConf = HALL.sectors[seat.sector];
        const pos = positions[seat.sector];
        const seatsInRow = getSeatsInRow(seat.sector, seat.row);
        const rowWidth = seatsInRow * seatUnit;
        const xOffset = (pos.width - rowWidth) / 2;
        const targetX = pos.x + xOffset + (seat.number - 1) * seatUnit + HALL.seatSize / 2;
        const targetY = seatsStartY + (seat.row - 1) * (HALL.seatSize + HALL.rowGap) + HALL.seatSize / 2;

        // Entrance position
        const entrancePositions = {
            A: positions.left.x + positions.left.width + HALL.sectorGap / 2,
            'Б': positions.center.x + positions.center.width + HALL.sectorGap / 2,
        };
        const entranceMap = { left: 'A', center: 'A', right: 'Б' };
        const myEntrance = entranceMap[seat.sector];
        const entranceX = entrancePositions[myEntrance];
        const sectorCenterX = pos.x + pos.width / 2;

        // Draw path
        const pathPoints = [
            `${entranceX},${HALL.entranceY - 15}`,
            `${sectorCenterX},${HALL.entranceY - 30}`,
            `${sectorCenterX},${targetY + HALL.seatSize}`,
            `${targetX},${targetY + HALL.seatSize}`,
            `${targetX},${targetY}`,
        ];

        const path = svgEl('polyline', {
            points: pathPoints.join(' '),
            class: 'nav-path',
            id: 'guest-nav-path',
        });
        svg.appendChild(path);

        // Pulsing circle around seat
        const circle = svgEl('circle', {
            cx: targetX, cy: targetY, r: 10,
            fill: 'none', stroke: '#ef4444', 'stroke-width': 2,
            opacity: 0.8, id: 'guest-nav-circle',
            class: 'seat-highlight',
        });
        svg.appendChild(circle);
    }

    // Show banner
    const banner = document.getElementById('found-guest-banner');
    if (banner) {
        banner.classList.remove('hidden');
        document.getElementById('found-guest-name').textContent = seat.guest_name;
        document.getElementById('found-guest-sector').textContent = seat.sector_label;
        document.getElementById('found-guest-row').textContent = seat.row;
        document.getElementById('found-guest-number').textContent = seat.number;
    }
}

function clearHighlight() {
    // Restore previously highlighted seat
    if (highlightedSeatId) {
        const prevEl = document.querySelector(`[data-seat-id="${highlightedSeatId}"]`);
        if (prevEl) {
            const prevData = allSeats.find(s => s.id === highlightedSeatId);
            if (prevData) {
                prevEl.setAttribute('class', getSeatClass(prevData));
                prevEl.style.fill = '';
                prevEl.style.opacity = '';
            }
        }
        highlightedSeatId = null;
    }

    // Remove nav path and circle
    const path = document.getElementById('guest-nav-path');
    const circle = document.getElementById('guest-nav-circle');
    if (path) path.remove();
    if (circle) circle.remove();
}

function clearGuestSearch() {
    clearHighlight();
    const banner = document.getElementById('found-guest-banner');
    if (banner) banner.classList.add('hidden');
    const input = document.getElementById('guest-search-input');
    if (input) input.value = '';
    const results = document.getElementById('search-results');
    if (results) results.classList.add('hidden');
}

function initSearch() {
    const input = document.getElementById('guest-search-input');
    const resultsDiv = document.getElementById('search-results');
    if (!input || !resultsDiv) return;

    input.addEventListener('input', function() {
        const query = this.value.trim();
        const matches = searchGuests(query);

        if (matches.length === 0) {
            if (query.length >= 2) {
                resultsDiv.innerHTML = '<div class="px-4 py-3 text-sm text-gray-500">Не найдено</div>';
                resultsDiv.classList.remove('hidden');
            } else {
                resultsDiv.classList.add('hidden');
            }
            return;
        }

        resultsDiv.innerHTML = matches.slice(0, 10).map(s => `
            <button class="w-full text-left px-4 py-2.5 text-sm hover:bg-gray-700 transition-colors flex items-center justify-between"
                    onclick="selectSearchResult(${s.id})">
                <span class="text-white font-medium">${s.guest_name} ${s.guest_category ? `<span class="text-xs text-blue-400 ml-2 border border-blue-500/30 bg-blue-500/10 px-1.5 py-0.5 rounded">${s.guest_category}</span>` : ''}</span>
                <span class="text-gray-400 text-xs">${s.sector_label}, Р${s.row} М${s.number}</span>
            </button>
        `).join('');
        resultsDiv.classList.remove('hidden');
    });

    // Close dropdown on outside click
    document.addEventListener('click', function(e) {
        if (!e.target.closest('#search-wrapper')) {
            resultsDiv.classList.add('hidden');
        }
    });
}

function selectSearchResult(seatId) {
    const seat = allSeats.find(s => s.id === seatId);
    if (!seat) return;

    const input = document.getElementById('guest-search-input');
    if (input) input.value = seat.guest_name;

    const resultsDiv = document.getElementById('search-results');
    if (resultsDiv) resultsDiv.classList.add('hidden');

    highlightGuestSeat(seat);

    // Also open right panel with full seat details
    selectSeat(seatId);
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', async function() {
    await loadHall();
    initSearch();
});
